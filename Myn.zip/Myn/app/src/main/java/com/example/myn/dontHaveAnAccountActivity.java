package com.example.myn;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class dontHaveAnAccountActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dont_have_an_account);
    }
}
