package com.example.myn.ui.send;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class SendViewModel extends ViewModel {

    private MutableLiveData<String> mText;

    public SendViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("Please contact us @ 000442037703333  or mail us @ stockbroking.info@lloydsbanking.com");
    }

    public LiveData<String> getText() {
        return mText;
    }
}