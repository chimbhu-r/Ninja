package com.example.myn;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


import org.w3c.dom.Text;

public class login1 extends AppCompatActivity {

    private TextView signIn;
    private TextView newAccount;
    private TextView fingerPrint;
    ActionBar actionbar;
    TextView textview;
    Toolbar.LayoutParams layoutparams;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Toolbar toolbar = (Toolbar) findViewById(R.id.t);
        // setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(true);
        //getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
        // getSupportActionBar().setCustomView(R.layout.abs_layout);
        //toolbar.setNavigationIcon(R.drawable.ic_toolbar);
        // toolbar.setTitle("");
        // toolbar.setSubtitle("");
        setContentView(R.layout.login1);

    }
    public void showText (View view) {

        String button_text;
        button_text = ((Button) view).getText().toString();
        if (button_text.equals("SIGN IN")) {
            Intent intent =new Intent(this, login2.class);
            startActivity(intent);
        }
        else if (button_text.equals("NEW USER")) {
            Intent intent =new Intent(this, dontHaveAnAccountActivity.class);
            startActivity(intent);
        }
        else if (button_text.equals("FINGER PRINT")) {
            Intent intent =new Intent(this, FingerPrintActivity.class);
            startActivity(intent);
        }
    }

}
