package com.example.myn;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class login2 extends AppCompatActivity {
    private EditText Name;
    private EditText Password;
    private TextView Info;
    private TextView Error;
    private Button Login;
    private int counter=5;
    private TextView forgotPassword;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().setDisplayShowTitleEnabled(true);
        setContentView(R.layout.login2);

        Name= (EditText)findViewById(R.id.userName);
        Password=(EditText)findViewById(R.id.passWord);
        Info=(TextView)findViewById(R.id.info);
        Error=(TextView)findViewById(R.id.info2);
        Login=(Button)findViewById(R.id.btnLogin);
        forgotPassword=(TextView)findViewById(R.id.forgotPassword);

        //Info.setText("No of attempts remaining : 5");

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(TextUtils.isEmpty(Name.getText())){
                    Name.setError("Username is required");
                }
                if(TextUtils.isEmpty(Password.getText()))
                {
                    Password.setError("Password is required");
                }
                else
                {
                    validate(Name.getText().toString(),Password.getText().toString());
                }

            }
        });

        forgotPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity((new Intent(login2.this, passwordActivity.class)));

            }
        });
    }

    private void validate(String userName, String userPassword){
        if((userName.equals("Admin")) && (userPassword.equals("1234"))){
            Intent intent = new Intent(login2.this, MainActivity.class);
            startActivity(intent);
        }
        else if(!userName.equals("Admin"))
        {
            Error.setText("User does not exist!");
        }
        else {
            counter--;
            Error.setText("Incorrect Password!");
            Info.setText("You have only : " + String.valueOf(counter) +" attempts left");
            if(counter == 0){
                Login.setEnabled(false);
            }
        }
    }
}




