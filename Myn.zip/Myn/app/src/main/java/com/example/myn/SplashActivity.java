package com.example.myn;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

/**
 * Created by Welcome on 6/15/2016.
 */
public class SplashActivity extends Activity {
    private final int splash_length=500;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splash);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent=new Intent(SplashActivity.this, login1.class);
                SplashActivity.this.startActivity(intent);
                SplashActivity.this.finish();

            }
        }, splash_length);


    }
}

