package com.example.myn;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class passwordActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_password);
    }
}
